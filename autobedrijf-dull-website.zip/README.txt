# Autobedrijf Dull — Planning

Open `index.html` in een browser. De planning werkt direct en bewaart afspraken lokaal in de browser.

Functies:
- Dashboard
- Dagplanning
- Nieuwe afspraken toevoegen
- Status: Gepland / Bezig / Klaar
- Zoeken/filteren op status
- Mobielvriendelijke weergave

Voor een echte bedrijfsversie kunnen we hierna database-opslag, meerdere medewerkers, klantgegevens, agenda-weekweergave en online inloggen toevoegen.
